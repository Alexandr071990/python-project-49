### Hexlet tests and linter status:
[![Actions Status](https://github.com/Alexandr071990/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Alexandr071990/python-project-49/actions)
<a href="https://codeclimate.com/github/Alexandr071990/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/4b9361ea8167b6ce9a3b/maintainability" /></a>

Запись работы игры brain-even:
https://asciinema.org/a/eWiyfTvbuYMMXiJSEOdh3G6QZ

Запись работы игры brain-calc:
https://asciinema.org/a/EU7hiJQrDtKZs7OIMJzJeND01